import 'package:flutter/material.dart';

void main() => runApp(const Plus90App());

class Plus90App extends StatelessWidget {
  const Plus90App({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      debugShowCheckedModeBanner: false,
      title: '+90',
      theme: ThemeData(
        brightness: Brightness.dark,
        scaffoldBackgroundColor: const Color(0xFF090B0F),
        colorScheme: ColorScheme.fromSeed(
          seedColor: const Color(0xFFD9A441),
          brightness: Brightness.dark,
        ),
        fontFamily: 'Roboto',
        useMaterial3: true,
      ),
      home: const DirectionGate(),
    );
  }
}

class DirectionGate extends StatefulWidget {
  const DirectionGate({super.key});

  @override
  State<DirectionGate> createState() => _DirectionGateState();
}

class _DirectionGateState extends State<DirectionGate> {
  bool arabic = true;

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: arabic ? TextDirection.rtl : TextDirection.ltr,
      child: Plus90Home(
        arabic: arabic,
        onLanguageChanged: (value) => setState(() => arabic = value),
      ),
    );
  }
}

class Plus90Home extends StatefulWidget {
  const Plus90Home({
    super.key,
    required this.arabic,
    required this.onLanguageChanged,
  });

  final bool arabic;
  final ValueChanged<bool> onLanguageChanged;

  @override
  State<Plus90Home> createState() => _Plus90HomeState();
}

class _Plus90HomeState extends State<Plus90Home> {
  int selectedTab = 0;

  String tr(String ar, String en) => widget.arabic ? ar : en;

  @override
  Widget build(BuildContext context) {
    final pages = [
      _homePage(),
      _simplePage(tr('المباريات', 'Matches'), tr('هنا ستظهر المباريات والنتائج المباشرة بعد ربط مزود البيانات.', 'Live fixtures and scores will appear here after connecting a data provider.')),
      _simplePage('Fantasy', tr('كوّن فريقك ونافس أصدقاءك.', 'Build your team and compete with friends.')),
      _simplePage(tr('المجتمع', 'Community'), tr('منشورات ونقاشات كروية فقط.', 'Football-only posts and discussions.')),
      _simplePage(tr('حسابي', 'Profile'), tr('ملفك الشخصي وإعداداتك ستظهر هنا.', 'Your profile and settings will appear here.')),
    ];

    return Scaffold(
      appBar: AppBar(
        backgroundColor: const Color(0xFF090B0F),
        titleSpacing: 18,
        title: Row(
          children: [
            Container(
              width: 38,
              height: 38,
              decoration: BoxDecoration(
                borderRadius: BorderRadius.circular(12),
                gradient: const LinearGradient(
                  colors: [Color(0xFFFFD879), Color(0xFFB77A20)],
                ),
              ),
              alignment: Alignment.center,
              child: const Text(
                '+90',
                style: TextStyle(
                  color: Color(0xFF111111),
                  fontWeight: FontWeight.w900,
                  fontSize: 17,
                ),
              ),
            ),
            const SizedBox(width: 10),
            const Text(
              '+90',
              style: TextStyle(fontWeight: FontWeight.w900, letterSpacing: 1.2),
            ),
            const Spacer(),
            IconButton(
              tooltip: tr('تغيير اللغة', 'Change language'),
              onPressed: () => widget.onLanguageChanged(!widget.arabic),
              icon: const Icon(Icons.language, color: Color(0xFFE3B454)),
            ),
            IconButton(
              tooltip: tr('الإشعارات', 'Notifications'),
              onPressed: () => _showMessage(tr('الإشعارات ستُفعّل في مرحلة الربط بالخادم.', 'Notifications will be enabled when the backend is connected.')),
              icon: const Icon(Icons.notifications_none),
            ),
          ],
        ),
      ),
      body: pages[selectedTab],
      bottomNavigationBar: NavigationBar(
        backgroundColor: const Color(0xFF11151C),
        indicatorColor: const Color(0x33D9A441),
        selectedIndex: selectedTab,
        onDestinationSelected: (index) => setState(() => selectedTab = index),
        destinations: [
          NavigationDestination(icon: const Icon(Icons.home_outlined), selectedIcon: const Icon(Icons.home), label: tr('الرئيسية', 'Home')),
          NavigationDestination(icon: const Icon(Icons.sports_soccer_outlined), selectedIcon: const Icon(Icons.sports_soccer), label: tr('المباريات', 'Matches')),
          const NavigationDestination(icon: Icon(Icons.emoji_events_outlined), selectedIcon: Icon(Icons.emoji_events), label: 'Fantasy'),
          NavigationDestination(icon: const Icon(Icons.forum_outlined), selectedIcon: const Icon(Icons.forum), label: tr('المجتمع', 'Community')),
          NavigationDestination(icon: const Icon(Icons.person_outline), selectedIcon: const Icon(Icons.person), label: tr('حسابي', 'Profile')),
        ],
      ),
    );
  }

  Widget _homePage() {
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 10, 16, 24),
      children: [
        Container(
          padding: const EdgeInsets.all(20),
          decoration: BoxDecoration(
            borderRadius: BorderRadius.circular(22),
            gradient: const LinearGradient(
              begin: Alignment.topRight,
              end: Alignment.bottomLeft,
              colors: [Color(0xFF292015), Color(0xFF12151B), Color(0xFF0D1016)],
            ),
            border: Border.all(color: const Color(0x55D9A441)),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(tr('كرة القدم… بعد الدقيقة 90', 'Football… beyond the 90th minute'),
                style: const TextStyle(color: Color(0xFFE7BD69), fontSize: 13, fontWeight: FontWeight.w700)),
              const SizedBox(height: 10),
              Text(tr('عِش كل لحظة', 'Live every moment'),
                style: const TextStyle(fontSize: 27, fontWeight: FontWeight.w900)),
              const SizedBox(height: 8),
              Text(tr('الأخبار، المباريات، الإحصائيات والفانتازي في مكان واحد.', 'News, matches, stats and fantasy — all in one place.'),
                style: const TextStyle(color: Colors.white70, height: 1.5)),
            ],
          ),
        ),
        const SizedBox(height: 22),
        _sectionTitle(tr('المباريات القادمة', 'Upcoming matches')),
        const SizedBox(height: 10),
        _matchCard('ARS', 'CHE', '20:30', 'Premier League'),
        _matchCard('RMA', 'BAR', '22:00', 'La Liga'),
        const SizedBox(height: 22),
        _sectionTitle(tr('استكشف +90', 'Explore +90')),
        const SizedBox(height: 10),
        GridView.count(
          crossAxisCount: 2,
          shrinkWrap: true,
          physics: const NeverScrollableScrollPhysics(),
          mainAxisSpacing: 10,
          crossAxisSpacing: 10,
          childAspectRatio: 1.55,
          children: [
            _feature(Icons.newspaper, tr('الأخبار', 'News'), tr('آخر أخبار الكرة', 'Latest football news')),
            _feature(Icons.query_stats, tr('الإحصائيات', 'Statistics'), tr('أرقام وتحليلات', 'Stats and analysis')),
            _feature(Icons.emoji_events, 'Fantasy', tr('نافس على القمة', 'Compete for the top')),
            _feature(Icons.groups, tr('المجتمع', 'Community'), tr('تحدث عن الكرة', 'Talk football')),
          ],
        ),
        const SizedBox(height: 16),
        const Text(
          'DEMO BUILD • SAMPLE DATA',
          textAlign: TextAlign.center,
          style: TextStyle(color: Colors.white30, fontSize: 10, letterSpacing: 1.4),
        ),
      ],
    );
  }

  Widget _sectionTitle(String title) => Text(
    title,
    style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w800),
  );

  Widget _matchCard(String home, String away, String time, String league) {
    return Container(
      margin: const EdgeInsets.only(bottom: 9),
      padding: const EdgeInsets.symmetric(horizontal: 15, vertical: 14),
      decoration: BoxDecoration(
        color: const Color(0xFF141922),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white10),
      ),
      child: Row(
        children: [
          Expanded(child: Text(home, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17))),
          Column(
            children: [
              Text(time, style: const TextStyle(color: Color(0xFFE7BD69), fontWeight: FontWeight.w800)),
              Text(league, style: const TextStyle(color: Colors.white54, fontSize: 10)),
            ],
          ),
          Expanded(child: Text(away, textAlign: TextAlign.end, style: const TextStyle(fontWeight: FontWeight.w900, fontSize: 17))),
        ],
      ),
    );
  }

  Widget _feature(IconData icon, String title, String subtitle) {
    return Container(
      padding: const EdgeInsets.all(13),
      decoration: BoxDecoration(
        color: const Color(0xFF141922),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(color: Colors.white10),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          Icon(icon, color: const Color(0xFFE3B454), size: 23),
          const SizedBox(height: 8),
          Text(title, style: const TextStyle(fontWeight: FontWeight.w800)),
          const SizedBox(height: 3),
          Text(subtitle, style: const TextStyle(color: Colors.white54, fontSize: 11)),
        ],
      ),
    );
  }

  Widget _simplePage(String title, String description) {
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(28),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            const Icon(Icons.construction, size: 42, color: Color(0xFFE3B454)),
            const SizedBox(height: 14),
            Text(title, style: const TextStyle(fontSize: 24, fontWeight: FontWeight.w900)),
            const SizedBox(height: 8),
            Text(description, textAlign: TextAlign.center, style: const TextStyle(color: Colors.white60, height: 1.5)),
          ],
        ),
      ),
    );
  }

  void _showMessage(String message) {
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(message)));
  }
}